package cs260.wou.edu;

import org.junit.*;
import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.Test;

public class SLQueueTester {
	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#size()}.
	 */
	@Test
	public void testSize() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		assertEquals("Size must be 0 after constructor", 0, testList.size());
		testList.clear( );
		assertEquals("Size must be 0 after clear", 0, testList.size());
		testList.add( 10);
		assertEquals("Size must be 1 after 1 add", 1, testList.size());
		testList.add( 20);
		assertEquals("Size must be 2 after 2 adds", 2, testList.size());
		testList.add( 30);
		assertEquals("Size must be 3 after 3 adds", 3, testList.size());
		testList.add( 40);
		assertEquals("Size must be 4 after 4 adds", 4, testList.size());
		testList.add( 15);
		assertEquals("Size must be 5 after 5 adds", 5, testList.size());
		testList.add( 25);
		assertEquals("Size must be 6 after 6 adds", 6, testList.size());
		testList.add( 35);
		assertEquals("Size must be 7 after 7 adds", 7, testList.size());
		testList.add( 45);
		testList.clear( );
		assertEquals("Size must be 0 after clear", 0, testList.size());
	}

	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#isEmpty()}.
	 */
	@Test
	public void testIsEmpty() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		assertTrue("IsEmpty must be true after the constructor", testList.isEmpty());	
		testList.clear( );
		assertTrue("IsEmpty must be true after the clear", testList.isEmpty());	
		testList.add( 10);
		testList.add( 20);
		assertFalse("IsEmpty must be false after the adds", testList.isEmpty());		
		testList.add( 30);
		testList.add( 40);
		assertFalse("IsEmpty must be false after the adds", testList.isEmpty());		
		testList.clear( );
		assertTrue("IsEmpty must be true after the clear", testList.isEmpty());	
		testList.clear( );
		assertTrue("IsEmpty must be true after the clear", testList.isEmpty());	
		testList.add( 10);
		testList.add( 20);
		assertFalse("IsEmpty must be false after the adds", testList.isEmpty());		
		testList.add( 30);
		testList.add( 40);
		assertFalse("IsEmpty must be false after the adds", testList.isEmpty());		
		testList.clear( );
		assertTrue("IsEmpty must be true after the clear", testList.isEmpty());		
	}


	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#add(java.lang.Object)}.
	 */
	@Test
	public void testAddT() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		testList.add( 10);
		assertEquals("Size must be 1 after the add", 1, testList.size());
		testList.add( 20);
		assertEquals("Size must be 2 after the add", 2, testList.size());
		testList.add( 30);
		assertEquals("Size must be 3 after the add", 3, testList.size());
		testList.add( 40);
		assertEquals("Size must be 4 after the add", 4, testList.size());
		testList.add( 50);
		assertEquals("Size must be 5 after the add", 5, testList.size());
		assertEquals("Remove must be 10 after the adds", (Integer)10, testList.remove());
		assertEquals("Remove must be 20 after the adds", (Integer)20, testList.remove());
		assertEquals("Remove must be 30 after the adds", (Integer)30, testList.remove());
		assertEquals("Remove must be 40 after the adds", (Integer)40, testList.remove());
		assertEquals("Remove must be 50 after the adds", (Integer)50, testList.remove());
	}
	
	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#add(java.lang.Object)}.
	 */
	@Test(expected = NullPointerException.class)
	public void testAddTExeption1() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		testList.add( 10);
		testList.add( 20);
		//Here is the real test for throwing exception
		testList.add( null);
	}		
	
	
	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#get(int)}.
	 */
	@Test
	public void testClear() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		assertEquals("Size must be 0 after constructor", 0, testList.size());
		testList.clear( );
		testList.clear( );
		assertEquals("Size must be 0 after clear", 0, testList.size());
		testList.clear( );
		testList.add( 10);
		testList.add( 20);
		testList.add( 30);
		testList.add( 40);
		testList.add( 15);
		testList.add( 25);
		testList.add( 35);
		testList.add( 45);
		assertEquals("Size must be 8 after adds", 8, testList.size());
		testList.clear( );
		assertEquals("Size must be 0 after clear", 0, testList.size());
	}	
	
	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#get(int)}.
	 */
	@Test
	public void testRemove() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		testList.clear( );
		assertTrue("IsEmpty must be true after the clear", testList.isEmpty());		
		testList.add( 10);
		testList.add( 20);
		testList.add( 30);
		testList.add( 40);
		testList.add( 50);
		assertEquals("Size must be 5 after adds", 5, testList.size());		
		assertEquals("Remove must return 10", (Integer)10, testList.remove());
		assertEquals("Size must be 4 after remove", 4, testList.size());		
		assertEquals("Remove must return 20", (Integer)20, testList.remove());
		assertEquals("Size must be 3 after remove", 3, testList.size());		
		assertEquals("Remove must return 30", (Integer)30, testList.remove());
		assertEquals("Size must be 2 after remove", 2, testList.size());		
		assertEquals("Remove must return 40", (Integer)40, testList.remove());
		assertEquals("Size must be 1 after remove", 1, testList.size());		
		assertEquals("Remove must return 50", (Integer)50, testList.remove());
		assertEquals("Size must be 0 after remove", 0, testList.size());		
	}	
	
	/**
	 * Test method for {@link edu.ccc.cs260.SpellChecker.DLList#get(int)}.
	 */
	@Test(expected = NoSuchElementException.class)
	public void testRemoveIntExeption1() {
		SLQueue<Integer> testList = new SLQueue<Integer>( ); 
		testList.add( 10);
		testList.add( 20);
		testList.add( 30);
		//Here is the real test for throwing exception
		testList.remove( );
		testList.remove( );
		testList.remove( );
		//Next one should throw the exception
		testList.remove( ); 
	}		
}
