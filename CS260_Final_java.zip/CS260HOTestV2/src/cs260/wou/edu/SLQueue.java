package cs260.wou.edu;

import java.util.Collection;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Queue;

public class SLQueue<E> implements Queue<E> {
	private int size;
	private Node head = null;
	private Node tail = null;
	
	class Node {
		E data; // Holds the data for the node
		Node next; // Points to the next node

		Node() { // Constructor 1
			this(null, null);
		}

		Node(E d) { //
			this(d, null);
		}

		Node(E d, Node n) {
			data = d;
			next = n;
		}
	}

	public boolean addAll(Collection<? extends E> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	public void clear() {
		// TODO Auto-generated method stub
		head = tail = null;
		size = 0;
		
	}

	public boolean contains(Object arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isEmpty() {
		// TODO Auto-generated method stub
		if (size == 0)
			return true;
		return false;
	}

	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}

	public int size() {
		// TODO Auto-generated method stub
		return size;
	}

	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}

	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean add(E e) {
		// TODO Auto-generated method stub
		if (e == null)
		{
			System.out.println("null pointer exception");
			return false;
			//return NullPointerException?
		}
		else if (size == 0)
		{
			head=tail= new Node(e);
			size++;
			return true;
		}
		else
		{
			tail.next = new Node(e);
			tail = tail.next;
			size++;
			return true;
		}
	}

	public E element() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean offer(E e) {
		// TODO Auto-generated method stub
		return false;
	}

	public E peek() {
		// TODO Auto-generated method stub
		return null;
	}

	public E poll() {
		// TODO Auto-generated method stub
		return null;
	}

	public E remove() {
		// TODO Auto-generated method stub
		if (size == 0)
		{
			return null;
			//throw NoSuchElementException
		}
		else
		{
			//Node retNode = new Node();
			E data = head.data;
			//retNode = head;
			head = head.next;
			size--;
			return data;
		}
		//return null;
	}

}
